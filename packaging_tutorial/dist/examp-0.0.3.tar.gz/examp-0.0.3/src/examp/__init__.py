# src/examp/__init__.py
def hello():
    return "Hello from examp!"
