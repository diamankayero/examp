# test_examp.py
import examp

print(examp.hello())
