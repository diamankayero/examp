import examp

# Si tu as ajouté une fonction comme hello() dans __init__.py
print(examp.hello())  # devrait afficher "Hello from examp!"
